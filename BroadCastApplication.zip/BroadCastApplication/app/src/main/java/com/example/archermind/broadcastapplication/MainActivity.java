package com.example.archermind.broadcastapplication;

import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private Button mBtnBroadCast;
    private TextView mTvContent;
    public static final String BROADCAST_ACTION = "com.example.corn";
    private BroadcastReceiver mBroadcastReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mBtnBroadCast = findViewById(R.id.btn_broadcast);
        mTvContent = findViewById(R.id.tv_content);
        //mTvContent.setText();
        mBtnBroadCast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction(BROADCAST_ACTION);
                intent.addFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES);
                intent.putExtra("name", "帅俊学长");
                sendBroadcast(intent);
            }
        });
//        int a =
        registerBroadcast();
    }

    private void registerBroadcast() {
        mBroadcastReceiver = new MyBroadcastReceiver();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(BROADCAST_ACTION);
        //亮屏广播
        intentFilter.addAction(Intent.ACTION_SCREEN_ON);
        registerReceiver(mBroadcastReceiver, intentFilter);

    }

    @Override
     protected void onDestroy() {
                super.onDestroy();
                 unregisterReceiver(mBroadcastReceiver);
                }
}
