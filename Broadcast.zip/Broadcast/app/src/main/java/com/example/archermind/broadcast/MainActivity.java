package com.example.archermind.broadcast;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

/**
 *在android7.0以后，自定义广播都是动态注册，系统广播可以静态注册
 */

public class MainActivity extends AppCompatActivity {
    private Button sendStaticButton,sendDynamicButton;

    private static final String STATICACTION = "com.example.archermind.staticreceiver";
    private static final String DYNAMICACTION = "com.example.archermind.dynamicreceiver";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sendStaticButton = findViewById(R.id.send_static);
        sendDynamicButton = findViewById(R.id.send_dynamic);
        sendStaticButton.setOnClickListener(new DIYOnClickListener());
        sendDynamicButton.setOnClickListener(new DIYOnClickListener());
    }

    class DIYOnClickListener implements View.OnClickListener{  //内部类OnClick监听器
        @Override
        public void onClick(View v) {
            switch (v.getId()){
                case R.id.send_static:                        // 发送自定义静态注册广播消息
                    Intent intent = new Intent();
                    intent.setAction(STATICACTION);            //设置Action
                    intent.putExtra("msg","接收静态注册广播成功！");  //添加附加信息
                    sendBroadcast(intent);                       //发送Intent
                    break;

                case R.id.send_dynamic:                            // 发送自定义动态注册广播消息
                    Intent intent1 = new Intent();
                    intent1.setAction(DYNAMICACTION);           //设置Action
                    intent1.putExtra("msg","接收动态注册广播成功！"); //添加附加信息
                    sendBroadcast(intent1);                        //发送Intent
                    break;
            }
        }
    }

    private BroadcastReceiver dynamicReceiver = new BroadcastReceiver() {   //动态广播的Receiver
        @Override
        public void onReceive(Context context, Intent intent) {
            if(intent.getAction().equals(DYNAMICACTION)){     //动作检测
                String msg = intent.getStringExtra("msg");
                Toast.makeText(context,msg,Toast.LENGTH_LONG).show();
            }
        }
    };

    @Override
    protected void onStart() {
        super.onStart();
        IntentFilter dynamic_filter = new IntentFilter();
        dynamic_filter.addAction(DYNAMICACTION);         //添加动态广播的Action
        registerReceiver(dynamicReceiver,dynamic_filter); // 注册自定义动态广播消息
    }
}
