package com.example.archermind.broadcast;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

import static android.content.ContentValues.TAG;

public class StaticReceiver extends BroadcastReceiver {

    @Override
    //静态广播接收器执行的方法
    public void onReceive(Context context, Intent intent) {
        String msg = intent.getStringExtra("msg");
        Log.e(TAG, "onReceive: "+msg );
        Toast.makeText(context,msg,Toast.LENGTH_LONG).show();
    }
}
