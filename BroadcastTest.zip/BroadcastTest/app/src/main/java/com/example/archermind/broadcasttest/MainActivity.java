package com.example.archermind.broadcasttest;

import android.content.Intent;
import android.content.IntentFilter;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Button mBtn1,mBtn2,mBtn3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mBtn1 = findViewById(R.id.btn_system);
        mBtn2 = findViewById(R.id.btn_my);
        mBtn3 = findViewById(R.id.btn_local);

        OnClick onClick = new OnClick();
        mBtn1.setOnClickListener(onClick);
        mBtn2.setOnClickListener(onClick);
        mBtn3.setOnClickListener(onClick);

    }
    class OnClick implements View.OnClickListener{

        @Override
        public void onClick(View v) {
            Intent intent = null;
            switch (v.getId()){
                case R.id.btn_system:
                    intent = new Intent(MainActivity.this,SystemBroadcastActivity.class);
                    break;
                case R.id.btn_my:
                    intent = new Intent(MainActivity.this,MyBroadcastActivity.class);
                    break;
                case R.id.btn_local:
                    intent = new Intent(MainActivity.this,LocalBrocastActivity.class);
                    break;
            }
            startActivity(intent);
        }
    }
}
