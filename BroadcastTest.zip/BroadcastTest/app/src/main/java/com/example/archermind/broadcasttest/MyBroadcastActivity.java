package com.example.archermind.broadcasttest;

import android.content.Intent;
import android.content.IntentFilter;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class MyBroadcastActivity extends AppCompatActivity {

    MyBroadcastReceiver myBroadcastReceiver = new MyBroadcastReceiver();
    IntentFilter intentFilter = new IntentFilter();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_broadcast);
        Button button = findViewById(R.id.btn_mybrocast);
        //注册广播
        intentFilter.addAction("com.example.broadcasttest.MY_BROADCAST");
        registerReceiver(myBroadcastReceiver,intentFilter);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent("com.example.broadcasttest.MY_BROADCAST");
//                sendBroadcast(intent);
                Log.e("sendBroadcastMyBroadcast","发送成功"+intent);
                //发送有序广播 其他应用程序也能收到
                sendOrderedBroadcast(intent,null);
            }
        });

    }

}
